import React from 'react';
import ReactDOM from 'react-dom/client';
import CompleteToplineApp from './CompleteToplineApp.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CompleteToplineApp />
  </React.StrictMode>
);
