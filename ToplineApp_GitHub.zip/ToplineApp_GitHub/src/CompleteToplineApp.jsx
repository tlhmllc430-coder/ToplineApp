import React, { useState, useRef } from 'react';

export default function CompleteToplineApp() {
  // --- STATE MANAGEMENT ---
  const [userTier, setUserTier] = useState('VIP'); 
  const [hasSignedAgreement, setHasSignedAgreement] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState('');
  
  // Media Recorder States
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState(null);
  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const [recordedChunks, setRecordedChunks] = useState([]);

  // AI Estimate & Image States
  const [jobRequest, setJobRequest] = useState('');
  const [selectedStrategy, setSelectedStrategy] = useState('CostEffective');
  const [aiOutput, setAiOutput] = useState(null);

  // Measurement States
  const [points, setPoints] = useState([]);
  const [calculatedDistance, setCalculatedDistance] = useState(null);

  // Gift Card States
  const [giftCardAmount, setGiftCardAmount] = useState('50');
  const [giftCardLog, setGiftCardLog] = useState([]);

  // --- FEATURE 1: CAMERA & AUDIO/VIDEO RECORDER ENGINE ---
  const startRecording = async () => {
    setRecordedChunks([]);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      const mimeCandidates = ['video/mp4', 'video/webm;codecs=vp8,opus', 'video/webm'];
      const mimeType = mimeCandidates.find((type) => MediaRecorder.isTypeSupported(type));
      const mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      let chunks = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: mediaRecorder.mimeType || 'video/webm' });
        setRecordedVideoUrl(URL.createObjectURL(blob));
        // Stop all tracks to turn off the physical device camera light
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Camera access denied or unavailable:", err);
      alert("Please grant camera/microphone permissions to use this tool.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // --- FEATURE 2: AI VARIETY GENERATOR & ESTIMATOR ---
  const generateAIEstimate = () => {
    if (!jobRequest) return alert("Please type your project request first.");
    
    // Core metrics mapped to business calculation algorithms
    const optionsData = {
      CostEffective: {
        label: "Most Cost Effective",
        priceRange: "$350 - $500",
        timeEstimate: "1 Day",
        breakdown: ["Basic Grade Materials", "Standard Hardware", "Minimum Labor Hours Required"],
        img: "https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?w=400&auto=format&fit=crop&q=60" // Minimal clean project placeholder
      },
      HighestQuality: {
        label: "Highest Quality (Premium)",
        priceRange: "$950 - $1400",
        timeEstimate: "3 - 4 Days",
        breakdown: ["Premium Hardwoods / Top-tier Metals", "Heavy-duty Structural Reinforced Fasteners", "Extended Precision Craftsmanship Work Schedule"],
        img: "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=400&auto=format&fit=crop&q=60" // Premium interior placeholder
      },
      Fastest: {
        label: "Fastest Priority Turnaround",
        priceRange: "$600 - $800",
        timeEstimate: "Half-Day Express",
        breakdown: ["Pre-fabricated Components", "Express Curing Sealants", "Dual Crew Staff Deployment Fee Included"],
        img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400&auto=format&fit=crop&q=60" // Rapid construction site mockup
      }
    };

    setAiOutput(optionsData[selectedStrategy]);
  };

  // --- FEATURE 3: ROOM PROXIMITY MEASUREMENT SIMULATOR ---
  // Calculates real world spatial dimensions using pixel ratios: $Distance = \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2} \times scale$
  const handleImageClick = (e) => {
    const rect = e.target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newPoints = [...points, { x, y }];
    if (newPoints.length > 2) {
      setPoints([{ x, y }]);
      setCalculatedDistance(null);
    } else {
      setPoints(newPoints);
      if (newPoints.length === 2) {
        const dx = newPoints[1].x - newPoints[0].x;
        const dy = newPoints[1].y - newPoints[0].y;
        const pixelDistance = Math.sqrt(dx * dx + dy * dy);
        const scaleFactor = 0.05; // 1 pixel = 0.05 feet conversion ratio simulation
        setCalculatedDistance((pixelDistance * scaleFactor).toFixed(1));
      }
    }
  };

  // --- FEATURE 4: DIGITAL GIFT CARDS ENGINE ---
  const purchaseGiftCard = () => {
    const cardId = `GC-${Math.floor(100000 + Math.random() * 900000)}`;
    const newCard = { id: cardId, balance: parseFloat(giftCardAmount).toFixed(2), date: new Date().toLocaleDateString() };
    setGiftCardLog([newCard, ...giftCardLog]);
    alert(`Success! Generated Digital Gift Card ${cardId} with value $${giftCardAmount}`);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-4 font-sans max-w-4xl mx-auto space-y-6">
      
      {/* HEADER SECTION */}
      <div className="bg-blue-600 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Topline Handyman LLC</h1>
          <p className="text-blue-100 text-sm">Enterprise Service Portal & Estimation Engine</p>
        </div>
        <div className="bg-slate-900/40 p-2 rounded-xl border border-white/10 flex gap-2 text-xs">
          <button onClick={() => setUserTier('Standard')} className={`px-3 py-1.5 rounded-lg font-bold transition ${userTier === 'Standard' ? 'bg-white text-slate-900' : 'text-slate-300'}`}>Standard User</button>
          <button onClick={() => setUserTier('VIP')} className={`px-3 py-1.5 rounded-lg font-bold transition ${userTier === 'VIP' ? 'bg-amber-400 text-slate-900' : 'text-amber-400/60'}`}>👑 VIP Member</button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">

        {/* TOOL 1: INTERACTIVE SMART SCANNER CAMERA */}
        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700 space-y-3">
          <h2 className="text-lg font-bold text-blue-400 flex items-center gap-2">📷 Smart Scanning & Triage Capture</h2>
          <p className="text-xs text-slate-400">Record video and audio explanations of your project goals and home repair requests directly.</p>
          
          <div className="aspect-video bg-slate-950 rounded-xl overflow-hidden border border-slate-700 relative flex items-center justify-center">
            {isRecording && <video ref={videoRef} autoPlay muted className="w-full h-full object-cover" />}
            {!isRecording && recordedVideoUrl && <video src={recordedVideoUrl} controls className="w-full h-full object-cover" />}
            {!isRecording && !recordedVideoUrl && <span className="text-xs text-slate-500">Camera Feed Dormant</span>}
            {isRecording && <span className="absolute top-3 right-3 bg-red-600 animate-pulse text-[10px] px-2 py-0.5 rounded-full font-bold">REC AUDIO+VIDEO</span>}
          </div>

          <div className="flex gap-2">
            {!isRecording ? (
              <button onClick={startRecording} className="flex-1 bg-blue-600 hover:bg-blue-500 py-2 rounded-xl text-xs font-bold transition">Activate Scanner</button>
            ) : (
              <button onClick={stopRecording} className="flex-1 bg-red-600 hover:bg-red-500 py-2 rounded-xl text-xs font-bold transition">Save & Compile Video</button>
            )}
          </div>
        </div>

        {/* TOOL 2: SPATIAL PROXIMITY MEASUREMENT TOOL */}
        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700 space-y-3">
          <h2 className="text-lg font-bold text-blue-400 flex items-center gap-2">📐 Photo Proximity Measure Tool</h2>
          <p className="text-xs text-slate-400">Tap two reference borders or spaces on the room template picture below to compute linear distance estimates.</p>
          
          <div className="relative inline-block w-full overflow-hidden rounded-xl border border-slate-700 cursor-crosshair">
            <img 
              src="https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600&auto=format&fit=crop&q=60" 
              alt="Room Area" 
              className="w-full select-none opacity-80"
              onClick={handleImageClick}
            />
            {points.map((pt, i) => (
              <div key={i} className="absolute bg-red-500 w-3 h-3 rounded-full border-2 border-white -translate-x-1/2 -translate-y-1/2 shadow-lg" style={{ left: pt.x, top: pt.y }} />
            ))}
          </div>

          <div className="flex justify-between items-center text-xs bg-slate-900 p-3 rounded-xl">
            <span>Points Dropped: <strong>{points.length}/2</strong></span>
            {calculatedDistance && <span className="text-emerald-400 font-mono text-sm">Estimated Space: <strong>{calculatedDistance} ft</strong></span>}
          </div>
        </div>

        {/* TOOL 3: AI IMAGE CONFIGURATOR & ITEMIZED ESTIMATES */}
        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700 space-y-4 md:col-span-2">
          <h2 className="text-lg font-bold text-blue-400 flex items-center gap-2">🧠 AI Variety Options & Itemized Breakdowns</h2>
          
          <div className="flex flex-col md:flex-row gap-3">
            <input 
              type="text"
              placeholder="e.g., Mount flat-screen TV and hide messy cables..."
              value={jobRequest}
              onChange={(e) => setJobRequest(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
            />
            <select 
              value={selectedStrategy} 
              onChange={(e) => setSelectedStrategy(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none"
            >
              <option value="CostEffective">Most Cost Effective</option>
              <option value="HighestQuality">Highest Quality</option>
              <option value="Fastest">Fastest Option</option>
            </select>
            <button onClick={generateAIEstimate} className="bg-emerald-600 hover:bg-emerald-500 px-5 py-2 rounded-xl text-sm font-bold transition">Process AI Options</button>
          </div>

          {aiOutput && (
            <div className="grid md:grid-cols-2 gap-4 bg-slate-900 p-4 rounded-xl border border-slate-700">
              <div className="space-y-2">
                <span className="text-xs uppercase bg-blue-900/60 border border-blue-700 text-blue-300 px-2 py-0.5 rounded font-bold">{aiOutput.label}</span>
                <div className="text-sm font-bold text-slate-300 mt-1">Est. Cost: <span className="text-emerald-400">{aiOutput.priceRange}</span></div>
                <div className="text-xs text-slate-400">Project Timeline: <span className="text-slate-200 font-semibold">{aiOutput.timeEstimate}</span></div>
                <p className="text-xs font-bold text-slate-400 pt-1 uppercase tracking-wider">Itemized Breakdown:</p>
                <ul className="text-xs space-y-1 list-disc list-inside text-slate-300">
                  {aiOutput.breakdown.map((item, idx) => <li key={idx}>{item}</li>)}
                </ul>
              </div>
              <div className="rounded-lg overflow-hidden border border-slate-700 aspect-video md:aspect-auto">
                <img src={aiOutput.img} alt="AI Structural Strategy Variant" className="w-full h-full object-cover" />
              </div>
            </div>
          )}
        </div>

        {/* TOOL 4: DIGITAL GIFT CARD SYSTEM & COMPLETED FORMS SIGN-OFF */}
        <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700 space-y-4 md:col-span-2 grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Buy Digital Gift Cards</h3>
            <div className="flex gap-2">
              <select value={giftCardAmount} onChange={(e) => setGiftCardAmount(e.target.value)} className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100">
                <option value="25">$25.00 GC</option>
                <option value="50">$50.00 GC</option>
                <option value="100">$100.00 GC</option>
              </select>
              <button onClick={purchaseGiftCard} className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-xl text-xs font-bold transition">Generate Gift Voucher</button>
            </div>
            {giftCardLog.length > 0 && (
              <div className="max-h-24 overflow-y-auto text-xs bg-slate-900 p-2 rounded-lg border border-slate-800 font-mono space-y-1">
                {giftCardLog.map((card) => <div key={card.id} className="text-slate-400">{card.date} - {card.id} (Balance: ${card.balance})</div>)}
              </div>
            )}
          </div>

          <div className="space-y-3 flex flex-col justify-end">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Transaction & Completion Agreement</h3>
            <label className="flex items-start gap-3 bg-slate-900 p-3 rounded-xl border border-slate-700 cursor-pointer">
              <input type="checkbox" checked={hasSignedAgreement} onChange={(e) => setHasSignedAgreement(e.target.checked)} className="mt-0.5 rounded text-blue-600 bg-slate-900 border-slate-700" />
              <span className="text-xs text-slate-300">I explicitly sign the <strong>Satisfied with Job Completion Agreement</strong>. Sign-off required for transaction deployment.</span>
            </label>
            <button onClick={() => {
              if(!hasSignedAgreement) return setPaymentStatus("❌ Blocked: Agreement checkbox unsigned.");
              setPaymentStatus("✅ Transaction Success: Funds routed to database.");
            }} className="w-full bg-emerald-600 hover:bg-emerald-500 py-2 rounded-xl text-xs font-bold transition">Process Deposit Checkout</button>
            {paymentStatus && <p className="text-xs font-semibold text-center mt-1">{paymentStatus}</p>}
          </div>
        </div>

      </div>
    </div>
  );
}
