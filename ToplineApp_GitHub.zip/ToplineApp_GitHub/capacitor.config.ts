import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.toplinehandyman.app',
  appName: 'Topline Handyman LLC',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
