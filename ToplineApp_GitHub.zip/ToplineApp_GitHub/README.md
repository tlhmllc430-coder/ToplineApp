# Topline Handyman LLC Android App

This repository packages the Topline Handyman React app as an Android APK using Capacitor and GitHub Actions.

## Build the APK

1. Upload these files to the `main` branch of the `tlhmllc430-coder/ToplineApp` repository.
2. Open **Actions** in GitHub.
3. Select **Build Topline Android APK**.
4. Run the workflow with **Run workflow**.
5. When it finishes, open the workflow run and download the **Functional_apk** artifact.

The artifact contains `Functional_apk.apk`.

## Included features

- Camera and microphone recording
- Room/photo distance estimate tool
- Estimate strategy selector
- Digital gift-card demo generator
- Job-completion agreement and simulated checkout status

## Important

The current payment/checkout and gift-card features are demo/local functionality. They do not connect to a real payment processor or gift-card fulfillment service.

The room measurement is an estimate based on a fixed pixel-to-feet simulation ratio and is not a calibrated measuring instrument.
